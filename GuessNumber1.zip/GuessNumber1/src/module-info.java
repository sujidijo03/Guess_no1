/**
 * 
 */
/**
 * 
 */
module GuessNumber1 {
}